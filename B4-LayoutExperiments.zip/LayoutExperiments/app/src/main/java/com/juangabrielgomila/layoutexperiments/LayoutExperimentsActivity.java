package com.juangabrielgomila.layoutexperiments;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class LayoutExperimentsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_layout_experiments);
        setContentView(R.layout.constraint_layout_experiments);


        final TextView tv = (TextView) findViewById(R.id.textView6);

        Button b1 = (Button) findViewById(R.id.button10);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv.setText(((Button)view).getText());
            }
        });


    }
}
