package com.juangabrielgomila.expressyourself;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int numMessages;

        numMessages = 10;

        Log.i("num messages", "El número de mensajes es de "+numMessages);

        numMessages++;
        numMessages +=1;
        Log.i("num messages", "El número de mensajes es de "+numMessages);//12

        boolean isMyFriend = true;
        Log.i("amigo", "El es mi amigo: "+isMyFriend);

        String from = "Juan Gabriel";
        String message = "Bienvenido a mi app con Android";
        Toast.makeText(MainActivity.this, "Mensaje de "+from, Toast.LENGTH_SHORT).show();
        Toast.makeText(this, "Mensaje: "+message, Toast.LENGTH_SHORT).show();



    }
}
