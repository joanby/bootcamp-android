package com.juangabrielgomila.loopsv2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class MainActivity extends AppCompatActivity {


    private static final String TAG = "MainActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int c = addAToB(3,6);// 3 + 6, c = 9

        doNothing();
        alwaysTrue();
        joinNames("Juan Gabriel", "Gomila");
    }


    public int addAToB(int a, int b){
        a = a+1;
        return a + b;
    }


    void doNothing(){
        return ;
    }

    boolean alwaysTrue(){
        return 5>2;
    }

    String joinNames(String name, String surname){
        return name + " " + surname;
    }


    void Hola(int a, boolean b, String c, char[] jj){

    }

    void HOLA(){

    }


    void eñe(){

    }



    public void forwardCount(View v){

        Log.i(TAG, "Entrando en cuenta adelante" );

        int x = 0;

        while(x<10){
            x++;
            Log.i(TAG, "x = "+x);
        }


    }

    public void backCount(View v){

        Log.i(TAG, "Entrando en la cuenta atrás");

        int x = 10;
        while (true){
            x--;
            Log.i(TAG, "x =  "+x);
            if (x == 0){
                break;
            }
        }

    }

    public void mixtCount(View v){
        Log.i(TAG, "Entrando en la cuenta mixta");

        for (int i = 0; i < 10; i ++){
            for(int j = 10; j > 0; j-- ){
                Log.i(TAG, " i = "+i+ ", j = "+j);
            }
        }

    }




}
