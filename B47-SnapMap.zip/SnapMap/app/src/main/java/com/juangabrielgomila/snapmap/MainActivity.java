package com.juangabrielgomila.snapmap;


//Librerías de compatibilidad y configuración
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.content.res.Configuration;
import android.os.Bundle;


//Fragments
import android.app.Fragment;
import android.app.FragmentManager;


//List View
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;


//Drawer Layout
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;


//ArrayAdapter
import android.widget.AdapterView;
import android.widget.ArrayAdapter;


//ActionBarDrawerToggle
import android.support.v7.app.ActionBarDrawerToggle;


//String
import android.util.Log;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    private ListView mNavDrawerListView;
    private DrawerLayout mDrawerLayout;
    private ArrayAdapter<String> mAdapter;
    private ActionBarDrawerToggle mDrawerToggle;
    private String mActivityTitle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mNavDrawerListView = (ListView) findViewById(R.id.nav_list);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mActivityTitle = getTitle().toString();

        String[] navMenuTitles = getResources().getStringArray(R.array.nav_drawer_items);
        mAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, navMenuTitles);
        mNavDrawerListView.setAdapter(mAdapter);


        setupDrawer();


        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);


        mNavDrawerListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int itemSelected, long l) {
                switchFragment(itemSelected);
            }
        });


        switchFragment(0);

    }


    private void switchFragment(int position){

        Fragment fragment = null;
        String fragmentID = "";

        switch (position){

            case 0:
                fragmentID = "TITLES";

                Bundle args = new Bundle();
                args.putString("Tag", "_NO_TAG");

                fragment = new TitlesFragment();
                fragment.setArguments(args);
                break;

            case 1:
                fragmentID = "TAGS";
                fragment = new TagsFragment();
                break;

            case 2:
                fragmentID = "CAPTURE";
                fragment = new CaptureFragment();
                break;

            default:
                //Aquí no deberíamos entrar nunca, salvo si añadimos una cuarta opción al menú lateral
                break;

        }

        //Aquí ya hemos decidido qué fragmento cargar...

        FragmentManager manager = getFragmentManager();

        manager.beginTransaction()
                .replace(R.id.fragment_holder, fragment, fragmentID)
                .commit();

        //Al final, como la selección viene de un nav drawer, estamos obligados a cerrarlo...
        mDrawerLayout.closeDrawer(mNavDrawerListView);

    }



    private void setupDrawer(){

        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout,
                R.string.drawer_open, R.string.drawer_close) {

            //Se llama cuando el menú lateral se muestra
            public void onDrawerOpened(View drawerView){
                super.onDrawerOpened(drawerView);

                getSupportActionBar().setTitle( getString(R.string.menu_choice) );

                //Llama de forma automática al método onPrepareOptionsMenu
                invalidateOptionsMenu();
            }

            //Se llama cuando el menú lateral se cierra
            public void onDrawerClosed(View drawerView){
                super.onDrawerClosed(drawerView);

                getSupportActionBar().setTitle(mActivityTitle);

                //Llama de forma automática al método onPrepareOptionsMenu
                invalidateOptionsMenu();
            }

        };

        mDrawerToggle.setDrawerIndicatorEnabled(true);

        //@deprecated: setDrawerListener...
        mDrawerLayout.addDrawerListener(mDrawerToggle);

    }


    @Override
    public void onPostCreate(@Nullable Bundle savedInstanceState, @Nullable PersistableBundle persistentState) {
        super.onPostCreate(savedInstanceState, persistentState);

        mDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        mDrawerToggle.onConfigurationChanged(newConfig);
    }


    @Override
    public void onBackPressed() {

        //Chequear si el drawer está abierto o no
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)){
            //Aquí el drawer está abierto
            //cerrar el drawer
            mDrawerLayout.closeDrawer(mNavDrawerListView);
        }else {
            //Aquí el drawer está cerrado
            //Tengo que volver al fragmento inicial (titles)
            //y si ya estoy en titles, debo cerrar la app
            Fragment currentFragment = getFragmentManager().findFragmentById(R.id.fragment_holder);
            if(currentFragment instanceof TitlesFragment){
                //Es el fragmento inicial, entonces debo salir de la app
                finish();
                System.exit(0);
            } else {
                //No estábamos en el fragmento inicial, así que lo cargamos
                switchFragment(0);
            }
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();
        if(id == R.id.menu_settings){
            Toast.makeText(this, "Se ha seleccionado el menú de opciones", Toast.LENGTH_SHORT).show();
        }


        if(mDrawerToggle.onOptionsItemSelected(item)){
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
