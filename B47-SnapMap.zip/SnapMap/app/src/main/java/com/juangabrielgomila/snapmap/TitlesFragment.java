package com.juangabrielgomila.snapmap;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.app.ListFragment;

/**
 * Created by JuanGabriel on 30/1/18.
 */

public class TitlesFragment extends ListFragment {

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


}
