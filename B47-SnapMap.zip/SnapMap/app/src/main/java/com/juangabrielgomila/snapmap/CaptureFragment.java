package com.juangabrielgomila.snapmap;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by JuanGabriel on 30/1/18.
 */

public class CaptureFragment extends Fragment {


    private static final int CAMERA_REQUEST = 1234;
    private ImageView mImageView;

    //Este es el path donde se guardará la foto
    String mCurrentPhotoPath;

    //Cuando capturemos la imagen, donde la guardaremos nosotros
    private Uri mImageUri = Uri.EMPTY;

    //Referencia a nuestro manager para acceder a la base de datos
    private DataManager mDataManager;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mDataManager = new DataManager(getActivity().getApplicationContext());
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_capture, container, false);

        mImageView = (ImageView) view.findViewById(R.id.image_view);

        Button btnCapture = (Button) view.findViewById(R.id.button_capture);
        Button btnSave = (Button) view.findViewById(R.id.button_save);

        final EditText mEditTextTitle = (EditText) view.findViewById(R.id.edit_text_title);
        final EditText mEditTextTag1 = (EditText) view.findViewById(R.id.edit_text_tag_1);
        final EditText mEditTextTag2 = (EditText) view.findViewById(R.id.edit_text_tag_2);
        final EditText mEditTextTag3 = (EditText) view.findViewById(R.id.edit_text_tag_3);


        btnCapture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

                File photoFile = null;

                try{

                    photoFile = createImageFile();

                }catch(IOException e){
                    e.printStackTrace();
                }

                //Si tenemos fichero de foto, podemos proceder a guardarlo

                if(photoFile!= null){

                    mImageUri = Uri.fromFile(photoFile);
                    cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, mImageUri);
                    startActivityForResult(cameraIntent, CAMERA_REQUEST);

                }


            }
        });//Fin de la lógica de capturar la foto


        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (mImageUri!=null){//Hay fichero
                    if (!mImageUri.equals(Uri.EMPTY)) {//El fichero no está vacío
                        //Aquí hay foto para guardar

                        Photo photo = new Photo();
                        photo.setTitle(mEditTextTitle.getText().toString());
                        photo.setStorageLocation(mImageUri);

                        photo.setTag1(mEditTextTag1.getText().toString());
                        photo.setTag2(mEditTextTag2.getText().toString());
                        photo.setTag3(mEditTextTag3.getText().toString());


                        mDataManager.addPhoto(photo);

                        Toast.makeText(getActivity(), "Imagen guardada correctamente en BD", Toast.LENGTH_LONG).show();
                    }else{
                        Toast.makeText(getActivity(), "No hay ninguna imagen para guardar", Toast.LENGTH_LONG).show();
                    }
                }else {
                    Toast.makeText(getActivity(), "ERROR GRAVE, URI nula", Toast.LENGTH_LONG).show();
                }



            }
        });//Fin de la lógica de guardado de la foto




        return view;
    }


    private File createImageFile() throws IOException{

        //Creamos el nombre de la foto basado en la fecha en que ha sido tomada
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "IMG_"+timeStamp+"_";

        File storeageDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);

        File image = File.createTempFile(
                imageFileName, //nombre del fichero a crear
                ".jpg", //extensión del fichero
                storeageDirectory //directorio o carpeta donde guardamos el fichero
        );

        //Guardamos para utilizarlo con el intent de Action View
        mCurrentPhotoPath = "file: "+image.getAbsolutePath();

        return image;

    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK) {

            try {
                mImageView.setImageURI(Uri.parse(mImageUri.toString()));
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            mImageUri = null;
        }

    }


    @Override
    public void onDestroy() {
        super.onDestroy();

        BitmapDrawable bd = (BitmapDrawable) mImageView.getDrawable();
        bd.getBitmap().recycle();
        mImageView.setImageBitmap(null);

    }
}
