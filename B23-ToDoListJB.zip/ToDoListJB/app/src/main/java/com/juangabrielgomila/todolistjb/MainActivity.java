package com.juangabrielgomila.todolistjb;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Note mTempNote = new Note();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Creamos una nueva instancia de Dialog Show Note
                DialogShowNote dialog = new DialogShowNote();
                //Indico al dialogo qué nota es la que debe mostrar por pantalla
                dialog.sendNoteSelected(mTempNote);
                //Mostramos el diálogo por pantalla, a través de un manager
                dialog.show(getFragmentManager(), "note_show");
            }
        });




    }


    public void createNewNote(Note newNote){
        //Este método, recibirá una nueva nota creada por el diálogo pertinente...
        mTempNote = newNote;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.action_add) {
            //Aquí debemos invocar una nueva instancia del diálogo para crear notas
            DialogNewNote dialog = new DialogNewNote();
            //Mostramos ese diálogo a través del manager
            dialog.show(getFragmentManager(),"note_create");
        }


        return false;
    }
}
