package com.juangabrielgomila.arrayliststest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //Declaración de un array list de enteros
        ArrayList<Integer> myList;

        //Inicialización del array list
        myList = new ArrayList<Integer>();

        //El método add añade siempre en la siguiente posición disponible
        myList.add(Integer.parseInt("5"));
        myList.add(Integer.parseInt("-8"));
        myList.add(Integer.parseInt("68"));
        //[5, -8, 68]

        //Si especificamos posición, nos permite añadir en una posición concreta (al igual que array[i])
        myList.add(1, Integer.parseInt("32"));
        //[5, 32, 68]



        ArrayList<String> names = new ArrayList<String>();

        names.add("Donald Trump");
        names.add("Ryan Gosling");
        names.add("Sansa Stark");

        names.add(2, "Tirion Lanister");


        //Preguntamos si el array list está vacío o no
        if (names.isEmpty()){
            //Aquí el array de nombres no tiene absolutamente nada
        }else {
            //Aquí hay cosas con las que trabajar en el array de nombres
        }


        //Cuantos objetos contiene el array list?
        int numItems = names.size();

        //Podemos saber donde hemos metido cierto objeto
        int position = names.indexOf("Ryan Gosling"); //en este caso, position valdría 1


        for (String s : names){
            Log.i("Personaje", s);
        }



        int[] anArray = {0,1,2,3,4,5,6};

        for (int i : anArray){
            Log.i("Enteros", ""+i);
        }



        //POLIMORFISMO
        Dog myDog = new Dog();
        Lion myLion = new Lion();
        Cat myCat = new Cat();
        Elephant myElephant = new Elephant();


        Animal[] animals = new Animal[4];
        animals[0] = myDog;
        animals[1] = myLion;
        animals[2] = myCat;
        animals[3] = myElephant;

        ArrayList<Animal> animalsList = new ArrayList<Animal>();
        animalsList.add(myDog);
        animalsList.add(myLion);
        animalsList.add(myCat);
        animalsList.add(myElephant);

        Object[] superMegaArray;//Aquí entra todas las cosas...



        //animals[2].miau();

        Cat c = (Cat) animals[2];
        c.miau();

        Animal a = animalsList.get(0);

        if(a instanceof Dog){
            Dog dog = (Dog) a;
            dog.guauGuau();
        }
        if (a instanceof Cat){
            Cat cat = (Cat) a;
            cat.miau();
        }
        if (a instanceof Lion){
            Lion l = (Lion) a;
        }



    }
}
