package com.juangabrielgomila.arrayliststest;

/**
 * Created by JuanGabriel on 27/11/17.
 */

public class Elephant extends Animal {
}
