package com.juangabrielgomila.arrayliststest;

/**
 * Created by JuanGabriel on 27/11/17.
 */

public class Dog extends Animal {

    public void guauGuau(){

    }
}
