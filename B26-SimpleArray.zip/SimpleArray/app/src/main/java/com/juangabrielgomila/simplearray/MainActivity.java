package com.juangabrielgomila.simplearray;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "Info";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //ARRAYS ESTÁTICO

        //Declara una variable de array de enteros
        int [] myArray;

        //Inicializamos el espacio en memoria para 5 enteros
        myArray = new int[5];

        //Inicializamos los 5 valores del array con números arbitrarios
        myArray[0] = 32;
        myArray[1] = 25;
        myArray[2] = 49;
        myArray[3] = 165;
        myArray[4] = 83;


        //Mostraremos los valores del array por consola
        Log.i(TAG, "Los valores de nuestro array son:");
        Log.i(TAG, "[0] = "+myArray[0]);
        Log.i(TAG, "[1] = "+myArray[1]);
        Log.i(TAG, "[2] = "+myArray[2]);
        Log.i(TAG, "[3] = "+myArray[3]);
        Log.i(TAG, "[4] = "+myArray[4]);


        //Vamos a sumar los 5 valores en una única variable
        int addition = myArray[0] + myArray[1] + myArray[2] + myArray[3] + myArray[4];
        Log.i(TAG, "La suma de los valores da: "+addition);




        //ARRAYS DINÁMICOS

        //Declarar y alojar espacio en memoria para 1000 números enteros
        int[] thousandInts = new int[1000];

        //Rellenamos ese array con los múltiplos de 5
        for (int i = 0; i<thousandInts.length; i++){ //thousandInts.length = 1000
            //En el paso actual del bucle, colocamos un múltiplo de 5
            thousandInts[i] = 5*i;

            //Vamos a imprimir el resultado de lo que hemos añadido por consola:
            Log.i(TAG, "i = " + i + ", thousandInts[i] = "+thousandInts[i]);
        }

        //Array Out Of Bounds Exception
        //Es el error que salta cuando intentamos meter o sacar algo
        //de una posición de un array que no existe...
        //int myValue = thousandInts[-5];
        //thousandInts[1000] = 836;

    }
}
