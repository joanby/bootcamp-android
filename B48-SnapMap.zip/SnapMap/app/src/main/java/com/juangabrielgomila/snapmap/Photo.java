package com.juangabrielgomila.snapmap;

import android.net.Uri;

/**
 * Created by JuanGabriel on 6/2/18.
 */

public class Photo {

    private String mTitle;
    private String mTag1, mTag2, mTag3;
    private Uri mStorageLocation;

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String title) {
        this.mTitle = title;
    }

    public String getTag1() {
        return mTag1;
    }

    public void setTag1(String tag) {
        this.mTag1 = tag;
    }

    public String getTag2() {
        return mTag2;
    }

    public void setTag2(String tag) {
        this.mTag2 = tag;
    }

    public String getTag3() {
        return mTag3;
    }

    public void setTag3(String tag) {
        this.mTag3 = tag;
    }

    public Uri getStorageLocation() {
        return mStorageLocation;
    }

    public void setStorageLocation(Uri uri) {
        this.mStorageLocation = uri;
    }
}
