package com.juangabrielgomila.snapmap;

/**
 * Created by JuanGabriel on 13/2/18.
 */

public interface ActivityCommunications {
    //Se llamará cuando se seleccione un título de imagen de la lista de disponibles
    void onTitlesListItemSelected(int pos);
    //Se llamará cuando se seleccione una tag de la lista de disponibles
    void onTagsListItemSelected(String tag);
}
