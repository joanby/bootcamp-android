package com.juangabrielgomila.snapmap;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.app.ListFragment;
import android.support.v4.widget.SimpleCursorAdapter;
import android.util.Log;
import android.view.View;
import android.widget.ListView;

/**
 * Created by JuanGabriel on 30/1/18.
 */

public class TagsFragment extends ListFragment {

    private ActivityCommunications mActComs;




    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        DataManager dm = new DataManager(getActivity().getApplicationContext());

        Cursor c = dm.getTags();

        SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                getActivity(),
                android.R.layout.simple_list_item_1,
                c,
                new String[]{DataManager.TABLE_ROW_TAG},
                new int[]{android.R.id.text1},
                0);

        setListAdapter(adapter);
    }


    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {


        //Cual ha sido la etiqueta que se ha seleccionado?
        Cursor c = ((SimpleCursorAdapter)l.getAdapter()).getCursor();
        c.moveToPosition(position);

        String clickedTag = c.getString(c.getColumnIndex(DataManager.TABLE_ROW_TAG));
        Log.d("Etiqueta = ", clickedTag);

        mActComs.onTagsListItemSelected(clickedTag);

    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mActComs = (ActivityCommunications) context;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mActComs = null;
    }
}
