package com.juangabrielgomila.snapmap;


import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.app.ListFragment;
import android.support.v4.widget.SimpleCursorAdapter;
import android.view.View;
import android.widget.ListView;

/**
 * Created by JuanGabriel on 30/1/18.
 */

public class TitlesFragment extends ListFragment {

    private Cursor mCursor;
    private ActivityCommunications mActComs;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Obtengo una referencia de las fotos que contienen una determinada tag
        String tag = getArguments().getString("tag");

        //Obtenemos un DM para hacer la búsqueda de fotos con dicha etiqueta
        DataManager dm = new DataManager(getActivity().getApplicationContext());

        if (tag == "_NO_TAG"){
            //Si el usuario no filta para una tag concreta, obtengo todos los titulos de la BD
            mCursor = dm.getTitles();
        } else {
            //Si el usuario ha seleccionado una tag, solo debo obtener los titulos con dicha tag
            mCursor = dm.getTitlesWithTag(tag);
        }


        //Adapter para rellenar una tabla...
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                getActivity(),
                android.R.layout.simple_list_item_1,
                mCursor,
                new String[]{DataManager.TABLE_ROW_TITLE},
                new int[]{android.R.id.text1},
                0);

        setListAdapter(adapter);
    }


    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {

        //Al hacer click en la posición indicada, debo notificar al cursor que se mueva a dicha fila
        mCursor.moveToPosition(position);
        //Cual es el ID en BD de este ítem?
        int dbID = mCursor.getInt(mCursor.getColumnIndex(DataManager.TABLE_ROW_ID));
        //Puedo notificar a la interface que se ha seleccionado dicho item
        mActComs.onTitlesListItemSelected(dbID);
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mActComs = (ActivityCommunications) context;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mActComs = null;
    }
}
