package com.juangabrielgomila.snapmap;

import android.app.Fragment;
import android.database.Cursor;
import android.graphics.drawable.BitmapDrawable;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by JuanGabriel on 13/2/18.
 */

public class ViewFragment extends Fragment {

    private Cursor mCursor;
    private ImageView mImageView;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Tengo foto para mostrar?
        int position = getArguments().getInt("position");

        //Cargamos la foto adecuada desde la base de datos
        DataManager dm = new DataManager(getActivity().getApplicationContext());

        //Obtenemos un cursor de la foto desde la BD gracias al DM
        mCursor = dm.getPhoto(position);

    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_view, container, false);

        TextView tv = (TextView) view.findViewById(R.id.text_view_title);
        Button btnMap = (Button) view.findViewById(R.id.button_show_map);
        mImageView = (ImageView) view.findViewById(R.id.image_view);

        //Del cursor de la BD, obtenemos la referencia a la columna que nos interesa
        //Forzamos en cada caso la obtención del tipo de datos pertinente, en nuestro caso Strings/URI
        tv.setText(mCursor.getString(mCursor.getColumnIndex(DataManager.TABLE_ROW_TITLE)));
        mImageView.setImageURI(Uri.parse(mCursor.getString(mCursor.getColumnIndex(DataManager.TABLE_ROW_URI))));

        return view;
    }


    @Override
    public void onDestroy() {
        super.onDestroy();

        //Vamos a asegurarnos que liberamos la memoria de las imágenes, para ello reciclaremos el bitmap
        BitmapDrawable bmd = (BitmapDrawable) mImageView.getDrawable();
        bmd.getBitmap().recycle();
        mImageView.setImageBitmap(null);

    }
}
