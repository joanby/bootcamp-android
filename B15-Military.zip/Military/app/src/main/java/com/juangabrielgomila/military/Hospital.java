package com.juangabrielgomila.military;

/**
 * Created by JuanGabriel on 30/10/17.
 */

class Hospital {


    protected void healSoldier(Soldier soldierToBeHealed){
        int health = soldierToBeHealed.getHealth();

        health += 20;

        soldierToBeHealed.setHealth(health);

    }


}
