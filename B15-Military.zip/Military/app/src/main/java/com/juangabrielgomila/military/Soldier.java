package com.juangabrielgomila.military;

import android.util.Log;

/**
 * Created by JuanGabriel on 30/10/17.
 */
public class Soldier {

    //Variables de la clase
    private int health;

    public int getHealth(){
        return health;
    }

    public void setHealth(int newHealth){

        if (newHealth<0){
            newHealth = 0;
        }

        if(newHealth>=100){
            newHealth = 100;
        }

        health = newHealth;
    }



    String soldierType;
    String name;


    //Constructor
    public Soldier(){
        this.health = 100;
    }

    public Soldier(String name, String soldierType, int health){
        this.name = name;
        this.soldierType = soldierType;
        this.health = health;

        //...
    }



    public Soldier(String name, String soldierType){
        this.name = name;
        this.soldierType = soldierType;
        this.health = 100;
    }




    //Métodos de la clase
    void shootEnemy(){

        Log.i(soldierType, "está disparando");

    }


    /*public void healSoldier(Soldier soldierToBeHealed){
        if (soldierToBeHealed.getHealth()<=0){
            return;
        }
        soldierToBeHealed.health += 20;

    }*/


    public void everybodyCanUseThisMethod(){

    }

    private void sendSecretMessage(){

    }

    void sendLessSecretMessage(){


    }

    protected void packageTask(){

    }



}
