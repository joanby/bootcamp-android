package com.juangabrielgomila.military;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);





        Soldier mySoldier;
        mySoldier = new Soldier();


        mySoldier.setHealth(100);
        mySoldier.soldierType = "sniper";


        //Aquí, tenemos un objeto llamado mySoldier
        //Es un objeto de la clase Soldier
        //La vida del soldado tiene 100 puntos y es un francotirador
        //ERROR: Solider.health = 100;


        mySoldier.shootEnemy();






        Soldier mySoldier2 = new Soldier();
        mySoldier2.setHealth(150);
        mySoldier2.soldierType = "special forces";
        mySoldier2.shootEnemy();



        //tenemos un soldado, llamado Rambo, que es muy difícil de matar
        Soldier rambo = new Soldier();
        rambo.setHealth(200);
        rambo.soldierType = "Green Beret";

        //Wellington es otro soldado, no tan fuerte como Rambo pero que puede ir por mar...
        Soldier wellington = new Soldier();
        wellington.setHealth(80);
        wellington.soldierType = "sailor";

        Log.i("RAMBO", "La vida de Rambo es de: "+rambo.getHealth());
        Log.i("WELLINGTON", "La vida de Wellington es de: "+wellington.getHealth());


        rambo.shootEnemy();
        wellington.shootEnemy();


        rambo.setHealth(rambo.getHealth()-150);

        Log.i("RAMBO", "La vida de Rambo es de: "+rambo.getHealth());


        /*Soldier medic = new Soldier();
        medic.setHealth(10);
        medic.soldierType = "Field Medical Soldier";


        medic.healSoldier(rambo);*/

        Hospital hospital = new Hospital();
        hospital.healSoldier(rambo);

        Log.i("RAMBO", "La vida de Rambo es de: "+rambo.getHealth());



        Soldier jb = new Soldier("JB", "Captain");
        Log.i("JB", "La vida de JB es de" +jb.getHealth());


        Soldier paco = new Soldier("Paco", "Infantery", 55);
        Log.i("Paco", "La vida de Paco es de  "+paco.getHealth());

        Toast.makeText(this, "", Toast.LENGTH_SHORT).show();


    }


}
