package com.juangabrielgomila.animationsdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity implements Animation.AnimationListener, View.OnClickListener {

    Animation animFadeIn, animFadeOut, animFadeInOut,
              animZoomIn, animZoomOut,
              animLeftRight, animTopBottom, animRightLeft,
              animBounce, animFlash,
              animRotateLeft, animRotateRight;

    ImageView imageView;
    TextView textViewStatus;

    Button  btnFadeIn, btnFadeOut, btnFadeInOut,
            btnZoomIn, btnZoomOut,
            btnLeftRight, btnTopBottom, btnRightLeft,
            btnBounce, btnFlash,
            btnRotateLeft, btnRotateRight;

    SeekBar seekBarSpeed;
    TextView textViewSeekSpeed;

    int seekSpeedProgress;

    private void loadAnimations(){

        animFadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        animFadeIn.setAnimationListener(this);

        animFadeOut = AnimationUtils.loadAnimation(this, R.anim.fade_out);
        animFadeOut.setAnimationListener(this);

        animFadeInOut = AnimationUtils.loadAnimation(this, R.anim.fade_in_out);
        animFadeInOut.setAnimationListener(this);

        animZoomIn = AnimationUtils.loadAnimation(this, R.anim.zoom_in);
        animZoomIn.setAnimationListener(this);

        animZoomOut = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
        animZoomOut.setAnimationListener(this);

        animLeftRight = AnimationUtils.loadAnimation(this, R.anim.left_right);
        animLeftRight.setAnimationListener(this);

        animTopBottom = AnimationUtils.loadAnimation(this, R.anim.top_bottom);
        animTopBottom.setAnimationListener(this);

        animRightLeft = AnimationUtils.loadAnimation(this, R.anim.right_left);
        animRightLeft.setAnimationListener(this);

        animBounce = AnimationUtils.loadAnimation(this, R.anim.bounce);
        animBounce.setAnimationListener(this);

        animFlash = AnimationUtils.loadAnimation(this, R.anim.flash);
        animFlash.setAnimationListener(this);

        animRotateLeft = AnimationUtils.loadAnimation(this, R.anim.rotate_left);
        animRotateLeft.setAnimationListener(this);

        animRotateRight = AnimationUtils.loadAnimation(this, R.anim.rotate_right);
        animRotateRight.setAnimationListener(this);

    }

    private void loadUI(){

        imageView = (ImageView) findViewById(R.id.image_view);
        textViewStatus = (TextView) findViewById(R.id.text_status);



        btnFadeIn = (Button) findViewById(R.id.btnFadeIn);
        btnFadeIn.setOnClickListener(this);

        btnFadeOut = (Button) findViewById(R.id.btnFadeOut);
        btnFadeOut.setOnClickListener(this);

        btnFadeInOut = (Button) findViewById(R.id.btnFadeInOut);
        btnFadeInOut.setOnClickListener(this);

        btnZoomIn = (Button) findViewById(R.id.btnZoomIn);
        btnZoomIn.setOnClickListener(this);

        btnZoomOut = (Button) findViewById(R.id.btnZoomOut);
        btnZoomOut.setOnClickListener(this);

        btnLeftRight = (Button) findViewById(R.id.btnLeftRight);
        btnLeftRight.setOnClickListener(this);

        btnTopBottom = (Button) findViewById(R.id.btnTopBottom);
        btnTopBottom.setOnClickListener(this);

        btnRightLeft = (Button) findViewById(R.id.btnRightLeft);
        btnRightLeft.setOnClickListener(this);

        btnBounce = (Button) findViewById(R.id.btnBounce);
        btnBounce.setOnClickListener(this);

        btnFlash = (Button) findViewById(R.id.btnFlash);
        btnFlash.setOnClickListener(this);

        btnRotateLeft = (Button) findViewById(R.id.btnRotateLeft);
        btnRotateLeft.setOnClickListener(this);

        btnRotateRight = (Button) findViewById(R.id.btnRotateRight);
        btnRotateRight.setOnClickListener(this);



        seekBarSpeed = (SeekBar) findViewById(R.id.seekBarSpeed);
        textViewSeekSpeed = (TextView) findViewById(R.id.textSeekSpeed);


        seekBarSpeed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int currentValue, boolean fromUser) {
                //Detecta un movimiento en la seek bar
                seekSpeedProgress = currentValue;
                textViewSeekSpeed.setText(seekSpeedProgress+"/"+seekBarSpeed.getMax());
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                //Detecta que el usuario empieza a mover una seek bar
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                //Detecta cuando el usuario acaba de mover la seek bar
            }
        });

    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        loadAnimations();
        loadUI();
    }





    /*
    * ...MÉTODOS DEL ANIMATION LISTENER...
    * */


    @Override
    public void onAnimationStart(Animation animation) {
        textViewStatus.setText("RUNNING");
    }

    @Override
    public void onAnimationEnd(Animation animation) {
        textViewStatus.setText("STOPPED");

    }

    @Override
    public void onAnimationRepeat(Animation animation) {
        textViewStatus.setText("REPEATING");
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.btnFadeIn:
                animFadeIn.setDuration(seekSpeedProgress);
                imageView.startAnimation(animFadeIn);
                break;

            case R.id.btnFadeOut:
                animFadeOut.setDuration(seekSpeedProgress);
                imageView.startAnimation(animFadeOut);
                break;

            case R.id.btnFadeInOut:
                animFadeInOut.setDuration(seekSpeedProgress);
                imageView.startAnimation(animFadeInOut);
                break;

            case R.id.btnZoomIn:
                animZoomIn.setDuration(seekSpeedProgress);
                imageView.startAnimation(animZoomIn);
                break;

            case R.id.btnZoomOut:
                animZoomOut.setDuration(seekSpeedProgress);
                imageView.startAnimation(animZoomOut);
                break;

            case R.id.btnLeftRight:
                animLeftRight.setDuration(seekSpeedProgress);
                imageView.startAnimation(animLeftRight);
                break;

            case R.id.btnTopBottom:
                animTopBottom.setDuration(seekSpeedProgress);
                imageView.startAnimation(animTopBottom);
                break;

            case R.id.btnRightLeft:
                animRightLeft.setDuration(seekSpeedProgress);
                imageView.startAnimation(animRightLeft);
                break;

            case R.id.btnBounce:
                //Dividimos la duración por 10, ya que la animación debe repetirse 10 veces, así que cada una
                //durará una décima parte del total que haya decidido el usuario!
                animBounce.setDuration(seekSpeedProgress/10);
                imageView.startAnimation(animBounce);
                break;

            case R.id.btnFlash:
                animFlash.setDuration(seekSpeedProgress/10);
                imageView.startAnimation(animFlash);
                break;

            case R.id.btnRotateLeft:
                animRotateLeft.setDuration(seekSpeedProgress);
                imageView.startAnimation(animRotateLeft);
                break;

            case R.id.btnRotateRight:
                animRotateRight.setDuration(seekSpeedProgress);
                imageView.startAnimation(animRotateRight);
                break;

        }
    }
}
