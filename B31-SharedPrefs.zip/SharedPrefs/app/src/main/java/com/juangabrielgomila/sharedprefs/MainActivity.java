package com.juangabrielgomila.sharedprefs;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {


    private static final String TAG = "MainActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Preferencias guardadas en disco solo lectura
        SharedPreferences prefs = getSharedPreferences("My Shared Prefernces App", MODE_PRIVATE);


        /*
        //Preferencias para leer y escribir (versión editable de las Shared Preferences)
        SharedPreferences.Editor editor = prefs.edit();


        String username = "Juan Gabriel";
        int age = 29;
        boolean knowsHowToMakeApps = true;

        //Guardamos las variables básicas que queramos en la versión editable de las SHared Preferences
        editor.putString("username", username);
        editor.putInt("age", age);
        editor.putBoolean("knowsHowToCode", knowsHowToMakeApps);

        //El commit guarda toda la información anterior en disco
        editor.commit();
        */


        String username = prefs.getString("username", "nuevo usuario");

        int age = prefs.getInt("age", -1);
        
        boolean knowsHowToCode = prefs.getBoolean("knowsHowToCode", false);


        Log.d(TAG, "El usuario se llama: " + username + " tiene "+age+" años y " +
                (knowsHowToCode? "sabe programar" : "no sabe programar")
        );



        if (username.compareTo("nuevo usuario") == 0){
            //Mostrar aquí una pantalla para seleccionar el nombre de usuario
        }

        if (age == -1){
            //La edad no ha sido configurada, mostrar un calendario para seleccionar la fecha de nacimiento
        }

        if (knowsHowToCode == false){
            //Mostrar ofertas de descuento en cursos de programación móvil
        }
        

    }
}
