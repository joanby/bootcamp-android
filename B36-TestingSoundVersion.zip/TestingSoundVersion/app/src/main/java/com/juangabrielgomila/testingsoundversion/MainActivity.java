package com.juangabrielgomila.testingsoundversion;

import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Spinner;

import java.io.IOException;

public class MainActivity extends AppCompatActivity
                          implements View.OnClickListener{

    //SOUND POOL
    SoundPool sp;
    int nowPlaying = -1;
    int idFX1 = -1;
    int idFX2 = -1;
    int idFX3 = -1;

    float volume = .1f;
    int repeats = 2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //Cargamos los cuatro botones de la pantalla
        Button bfx1 = (Button) findViewById(R.id.btnFX1);
        bfx1.setOnClickListener(this);

        Button bfx2 = (Button) findViewById(R.id.btnFX2);
        bfx2.setOnClickListener(this);

        Button bfx3 = (Button) findViewById(R.id.btnFX3);
        bfx3.setOnClickListener(this);

        Button bStop = (Button) findViewById(R.id.btnStop);
        bStop.setOnClickListener(this);


        //Cargamos el pool de sonidos según la versión de Android
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP){
            //El codigo de lollipop o posterior, aquí dentro
            //El nuevo modo de inicializar un SoundPool es con AudioAtributtes
            AudioAttributes attr = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();

            sp = new SoundPool.Builder()
                    .setMaxStreams(5)
                    .setAudioAttributes(attr)
                    .build();
        } else {
            //El codigo anterior para dispositivos más viejos
            //aquí dentro
            sp = new SoundPool(5, AudioManager.STREAM_MUSIC, 0);
        }

        //Cargamos el pool de sonidos con los diferentes audio de la carpeta assets
        try{
            AssetManager manager = this.getAssets();
            AssetFileDescriptor descriptor;

            //Cargamos en memoria el audio llamado fx1.ogg
            descriptor = manager.openFd("fx1.ogg");
            idFX1 = sp.load(descriptor,0);

            descriptor = manager.openFd("fx2.ogg");
            idFX2 = sp.load(descriptor,0);

            descriptor = manager.openFd("fx3.ogg");
            idFX3 = sp.load(descriptor,0);

        }catch(IOException e){
            e.printStackTrace();
        }

        //Cargamos la seekbar y creamos una clase anónima para gestionar sus cambios
        SeekBar seekbar = (SeekBar) findViewById(R.id.seekBar);
        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int value, boolean fromUser) {
                volume = value / 10.0f; //la seekbar va de 0 a 10, el volumen de 0 a 1
                sp.setVolume(nowPlaying, volume, volume);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                //No lo vamos a usar
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                //No lo vamos a usar
            }
        });


        final Spinner spinner = (Spinner) findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String temp = String.valueOf(spinner.getSelectedItem());
                repeats = Integer.valueOf(temp);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //Aquí no va nada
            }
        });

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btnFX1:
                sp.stop(nowPlaying);
                nowPlaying = sp.play(idFX1, volume, volume, 0, repeats, 1);
                break;

            case R.id.btnFX2:
                sp.stop(nowPlaying);
                nowPlaying = sp.play(idFX2, volume, volume, 0, repeats, 1);
                break;

            case R.id.btnFX3:
                sp.stop(nowPlaying);
                nowPlaying = sp.play(idFX3, volume, volume, 0, repeats, 1);
                break;

            case R.id.btnStop:
                sp.stop(nowPlaying);
                break;
        }
    }
}
