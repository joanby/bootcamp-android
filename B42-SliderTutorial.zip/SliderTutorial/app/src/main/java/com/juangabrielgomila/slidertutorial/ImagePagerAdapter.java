package com.juangabrielgomila.slidertutorial;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

/**
 * Created by JuanGabriel on 23/1/18.
 */

public class ImagePagerAdapter extends PagerAdapter {

    Context context;

    int[] images;

    LayoutInflater inflater;



    public ImagePagerAdapter(Context contect, int[] images){
        this.context = contect;
        this.images = images;
    }


    @Override
    public int getCount() {
        return this.images.length;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {

        ImageView imageview;

        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View itemView = inflater.inflate(R.layout.pager_item, container, false);

        imageview = (ImageView) itemView.findViewById(R.id.image_view);

        imageview.setImageResource(images[position]);

        ((ViewPager) container).addView(itemView);

        return itemView;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {

        ((ViewPager) container).removeView((RelativeLayout) object);

    }
}
