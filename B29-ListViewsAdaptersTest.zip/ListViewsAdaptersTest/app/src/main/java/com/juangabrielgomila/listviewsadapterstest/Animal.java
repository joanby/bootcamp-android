package com.juangabrielgomila.listviewsadapterstest;

/**
 * Created by JuanGabriel on 27/11/17.
 */

public class Animal {
    public String name;

    public Animal (String name){
        this.name = name;
    }
}
