package com.juangabrielgomila.listviewsadapterstest;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by JuanGabriel on 27/11/17.
 */

public class MyOwnAdapter extends BaseAdapter {

    List<Animal> myList = new ArrayList<Animal>();


    @Override
    public int getCount() {
        return myList.size();
    }

    @Override
    public Animal getItem(int itemPos) {
        return myList.get(itemPos);
    }

    @Override
    public long getItemId(int itemPos) {
        return itemPos;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        /*
        * Aquí, recuperamos el objeto en la posición i-ésima que debe ser mostrado.
        * Preparamos la vista con los objetos del layout que hayamos creado en su momento
        * Rellenamos la infomración de esos widgets con el objeto
        * Para acabar, se infla la vista dentro de la view group
        * */
        return null;
    }
}
