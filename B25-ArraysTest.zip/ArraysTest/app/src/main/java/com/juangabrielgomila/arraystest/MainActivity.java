package com.juangabrielgomila.arraystest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    //int topScore1, topScore1, topScore3,..., topScore100;
    int [] topScores = new int[100];//este array podrá guardar hasta 100 puntuaciones enteras como máximo
    String [] classNames;
    boolean [] arrayOfPass;
    float [] walletBalances;

    Note [] myNotes;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        classNames = new String[20];
        walletBalances = new float[20];

        myNotes = new Note[30];


        //ASignación de variables en un array
        //Los arrays empiezan en cero...
        //Como tiene 100 posiciones, la última que será accesible será la 99
        topScores[0] = 7;
        topScores[1] = 6;
        topScores[2] = 4;

        //INtentar meter un string donde hemos reservado espacio para enteros, da error...
        //topScores[3] = "Juan Gabriel";

        topScores[3] = topScores[2]-topScores[1]; //4-6 = -2

        int myIntVariable = topScores[3];

        myIntVariable = 8; //Ahora myIntVariable vale 8, pero topScores[3] sigue valiendo -2...


        int arrayLength = topScores.length; //El parámetro length de un array me dice cuantos elementos puede guardar...

        String[][] countriesAndCities;

        countriesAndCities = new String[3][5];
        //ciudad 0 = país,
        countriesAndCities[0][0] = "España";
        countriesAndCities[0][1] = "Madrid";
        countriesAndCities[0][2] = "Valencia";
        countriesAndCities[0][3] = "Palma";
        countriesAndCities[0][4] = "Bilbao";

        countriesAndCities[1][0] = "Francia";
        countriesAndCities[1][1] = "París";
        countriesAndCities[1][2] = "Lyon";
        countriesAndCities[1][3] = "Nantes";
        countriesAndCities[1][4] = "Cannes";

        countriesAndCities[2][0] = "Estados Unidos";
        countriesAndCities[2][1] = "Washington";
        countriesAndCities[2][2] = "Nueva York";
        countriesAndCities[2][3] = "Seattle";
        countriesAndCities[2][4] = "San Francisco";


        String [] spanishCities = countriesAndCities[0];

    }
}
