package com.juangabrielgomila.arraystest;

/**
 * Created by JuanGabriel on 27/11/17.
 */

public class Note {
    public String noteContent;
}
