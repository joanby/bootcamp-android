package com.juangabrielgomila.databaseexample;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.util.StringBuilderPrinter;

/**
 * Created by JuanGabriel on 6/2/18.
 */

public class DataManager {

    //Referencia a la base de datos
    private SQLiteDatabase db;

    /*Referencia a cada una de las columnas de la tabla a tratar
    * Las hacemos públicas para usarlas tanto en el DM como fuera de él*/

    public static final String TABLE_ROW_ID = "_id";
    public static final String TABLE_ROW_NAME = "name";
    public static final String TABLE_ROW_AGE = "age";


    /*Referencia a cada tabla de la base de datos
    * Las hacemos privadas porque nadie salvo el DM necesita saber de la estructura de la BD*/
    private static final String DB_NAME = "AddressBookDb";
    private static final int DB_VERSION = 1;
    private static final String TABLE_NAMES_AND_ADDRESS = "NamesAndAddresses";

    public DataManager(Context context){
        //Creamos nuestra propia instancia del helper interno para conectarnos a la BD
        MyCustomSQLiteOpenHelper helper = new MyCustomSQLiteOpenHelper(context);

        //Obtenemos del helper una base de datos para leer y escribir...
        db = helper.getWritableDatabase();
    }



    //Las operacionees con la BD se implementan como métodos de nuestro Data Manager

    //Insertar un nuevo usuario
    public void insert(String name, String age)
    {
        /*
        * INSERT INTO NamesAndAddresses (name, age) VALUES
        *   ('name', 'age');
        * */
        String query = "INSERT INTO " +
                TABLE_NAMES_AND_ADDRESS + " ("+
                    TABLE_ROW_NAME + ", "+
                    TABLE_ROW_AGE + ") "+
                    "VALUES (" +
                        "'"+name+"'" + ", "+
                        "'"+age+"'"+
                    ");";
        Log.i("insert() = ", query);
        db.execSQL(query);
    }

    //Borrar un usuario existente
    public void delete(String name)
    {
        //DELETE FROM NamesAndAddresses WHERE name = 'name';
        String query = "DELETE FROM "+
                TABLE_NAMES_AND_ADDRESS +
                    " WHERE "+ TABLE_ROW_NAME +
                    " = '"+name+"';";

        Log.i("delete() = ", query);

        db.execSQL(query);
    }

    //Obtener un usuario concreto
    public Cursor search(String name)
    {
        String query = "SELECT "+
                TABLE_ROW_ID + ", "+
                TABLE_ROW_NAME + ", "+
                TABLE_ROW_AGE +
                " FROM " +
                    TABLE_NAMES_AND_ADDRESS +
                    " WHERE " +
                    TABLE_ROW_NAME +" = '"+name+"';";
        Log.i("search() = ", query);

        Cursor c = db.rawQuery(query, null);
        return c;
    }

    //Obtener todos los usarios de la base de datos
    public Cursor selectAll(){
        String query = "SELECT * FROM "+TABLE_NAMES_AND_ADDRESS;
        Log.i("selectAll() = ", query);

        Cursor c = db.rawQuery(query, null);
        return c;
    }


    /*
    * Clase interna para gestionar nuestro propio helper de conexión
    * a la base de datos de la App
    * */
    private class MyCustomSQLiteOpenHelper extends SQLiteOpenHelper{

        public MyCustomSQLiteOpenHelper(Context context) {
            super(context, DB_NAME, null, DB_VERSION);
        }

        /*Solamente se ejecuta la primera vez que arranca la app
        * y debe crearse la base de datos...*/
        @Override
        public void onCreate(SQLiteDatabase db) {

            String newTablesQuery = "CREATE TABLE "+
                    TABLE_NAMES_AND_ADDRESS + " ("+
                        TABLE_ROW_ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "+
                        TABLE_ROW_NAME + " TEXT NOT NULL, "+
                        TABLE_ROW_AGE + " TEXT NOT NULL); ";

            Log.i("Creating Database ", newTablesQuery);
            Log.i("Database value", ""+db);

            db.execSQL(newTablesQuery);

        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            //Aquí no implementaremos nada hasta tener mejoras de la base de datos
            if(oldVersion < newVersion ){
                //Aquí implementariamos todas las mejoras desde oldVersion+1 hasta newVersion
                for (int i = oldVersion +1; i<=newVersion; i++){
                    Log.i("Upgrading Database", "Estamos haciendo la actualización número  "+i);
                    updateToVersion(i);
                }
            }
        }


        private void updateToVersion(int versionToUpdate){
            switch (versionToUpdate){
                case 1:
                    //Crear una base de datos..
                    break;
                case 2:
                    //Insertar un campo a la tabla XXX
                    break;
                case 3:
                    //Destruir ua tabla que ya no se usa...
                    break;
                case 4:
                    String query = String.valueOf(R.string.update_4);
                    //ejecutar update a partir de la query de strings...
                    break;
                default:
                    //Aquí no debería entrar nunca...
                    break;
            }
        }
    }

}
