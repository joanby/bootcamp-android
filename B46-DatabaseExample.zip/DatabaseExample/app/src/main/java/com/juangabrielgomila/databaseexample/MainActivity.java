package com.juangabrielgomila.databaseexample;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    //Referencias a los cuatro botones y edit text de la UI de la actividad
    Button btnInsert, btnDelete, btnSearch, btnSelect;
    EditText editName, editAge, editDelete, editSearch;

    //Referencia a nuestro data manager para llamar a los diferentes métodos según el botón pulsado
    DataManager dm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dm = new DataManager(this);

        btnInsert = (Button) findViewById(R.id.btn_insert);
        btnDelete = (Button) findViewById(R.id.btn_delete);
        btnSearch = (Button) findViewById(R.id.btn_search);
        btnSelect = (Button) findViewById(R.id.btn_search_all);

        editName = (EditText) findViewById(R.id.edit_name);
        editAge = (EditText) findViewById(R.id.edit_age);
        editDelete = (EditText) findViewById(R.id.edit_delete);
        editSearch = (EditText) findViewById(R.id.edit_search);


        btnInsert.setOnClickListener(this);
        btnDelete.setOnClickListener(this);
        btnSearch.setOnClickListener(this);
        btnSelect.setOnClickListener(this);
    }

    /*Método que desde el cursor nos recorrerá toda la información que queremos mostrar...
    * */
    public void showData(Cursor c){
        while (c.moveToNext()){
            Log.i(c.getString(1), c.getString(2));
        }
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){

            case R.id.btn_insert:
                //Aquí podemos filtrar antes de llamar al DM, la información que el usuario ha metido en las edit text
                dm.insert(editName.getText().toString(), editAge.getText().toString());
                break;

            case R.id.btn_delete:
                dm.delete(editDelete.getText().toString());
                break;

            case R.id.btn_search:
                showData(dm.search(editSearch.getText().toString()));
                break;

            case R.id.btn_search_all:
                showData(dm.selectAll());
                break;


        }



    }
}
