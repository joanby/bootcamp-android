package com.juangabrielgomila.safari;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        Elephant e = new Elephant(15, 700);

        e = (Elephant) feed(e);



        Animal a = new Elephant(15, 800);


        //Lion l = (Lion) a;

        //Animal a2 = new Animal();

        //No se puede instanciar una clase abstracta
        //SomeClass c = new SomeClass();


    }



    Animal feed(Animal animalToBeFeed){
        //Aquí tenemos un animal a ser alimentado, sin importar cual sea este animal
        return animalToBeFeed;
    }





}
