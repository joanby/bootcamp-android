package com.juangabrielgomila.safari;

/**
 * Created by JuanGabriel on 6/11/17.
 */

public abstract class SomeClass {
    /*
    * Todas las variables y métodos van exactamente igual
    * La diferencia es que esta clase nunca va a ser instanciada como tal...
    *
    * */
}
