package com.juangabrielgomila.safari;

public class Elephant extends Animal{

    public Elephant(int age, int weight){

        this.age = age;
        this.weight = weight;
        this.type = "Elefante";
        this.hungerLevel = 0;

    }



}



