package com.juangabrielgomila.safari;

/**
 * Created by JuanGabriel on 6/11/17.
 */

public abstract class Animal {

    //Variables de clase
    public int age;
    public int weight;
    public String type;
    public int hungerLevel;


    public void eat(){
        hungerLevel--;
    }

    public void walk(){
        hungerLevel++;
    }

}




