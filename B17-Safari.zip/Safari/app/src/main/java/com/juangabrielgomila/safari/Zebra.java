package com.juangabrielgomila.safari;

public class Zebra extends Animal {
    public Zebra(int age, int weight){
        this.age = age;
        this.weight = weight;
        this.type = "Cebra";
        this.hungerLevel = 0;
    }
}
