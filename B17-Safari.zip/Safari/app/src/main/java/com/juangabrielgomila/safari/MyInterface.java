package com.juangabrielgomila.safari;

/**
 * Created by JuanGabriel on 6/11/17.
 */

public interface MyInterface {

    //Todos los métodos de una interface son siempre:
    //- públicos para ser accedidos
    //- abstractos para ser implementados

    void someAbstractMethod();

    int anotherAbstractMethod(int a);

    public abstract void someExplicitAbstractAndPublicMethod();


}
