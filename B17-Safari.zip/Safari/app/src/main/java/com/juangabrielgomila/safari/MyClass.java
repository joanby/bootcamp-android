package com.juangabrielgomila.safari;

/**
 * Created by JuanGabriel on 6/11/17.
 */

public class MyClass implements MyInterface{


    //Variables de clase


    //Constructores


    //Métodos




    @Override
    public void someAbstractMethod() {
        //Aqui implemento lo que me de la gana, como un COMPORTAMIENTO de la interface
    }

    @Override
    public int anotherAbstractMethod(int a) {
        //Aquí tengo otro comportamiento que puedo implementar
        return 2*a+5;
    }

    @Override
    public void someExplicitAbstractAndPublicMethod() {
        //Idem....
    }


}
