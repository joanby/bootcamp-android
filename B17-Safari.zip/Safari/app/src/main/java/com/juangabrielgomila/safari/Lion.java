package com.juangabrielgomila.safari;

public class Lion extends Animal{

    public Lion(int age, int weight){
        this.age = age;
        this.weight = weight;
        this.type = "León";
        this.hungerLevel = 0;
    }

}



