package com.juangabrielgomila.safari;

public class Toad extends Animal {

    public Toad(int age, int weight){
        this.age = age;
        this.weight = weight;
        this.type = "Rana";
        this.hungerLevel = 0;
    }

}


