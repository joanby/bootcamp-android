package com.juangabrielgomila.mediaplayer;

import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            MediaPlayer mp = new MediaPlayer();
            mp.setDataSource(this.getAssets().openFd("nombredelfichero.mp3"));
            mp.prepare();
            mp.start();
        }catch(IOException e){
            e.printStackTrace();
        }

    }
}
