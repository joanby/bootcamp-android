package com.juangabrielgomila.spaceinheritance;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        //El constructor, crea las naves con las respectivas vidas que les toquen
        Fighter fighter = new Fighter();
        Bomber bomber = new Bomber();

        //No se puede instanciar una clase que es abstracta...
        //SpaceShip spaceShip = new SpaceShip();

        //Las variables públicas se pueden consultar y modificar desde cualquier lado
        fighter.shipName = "Ned Stark";
        bomber.shipName  = "Lara Croft";

        //Las variables privadas, necesitan ser accedidas a través de su getter respectivo
        Log.i("Fighter", "La vida de : "+fighter.shipName + " es de "+fighter.getShieldStrength());
        Log.i("Bomber", "La vida de : "+bomber.shipName + " es de "+bomber.getShieldStrength());

        //Cada nave tiene su propia implementación del método abstracto disparar
        fighter.fireWeapon();
        bomber.fireWeapon();


        //Al recibir muchos golpes, la nave, acaba siendo destruida
        bomber.hitDetected();
        bomber.hitDetected();
        bomber.hitDetected();
        bomber.hitDetected();



    }
}
