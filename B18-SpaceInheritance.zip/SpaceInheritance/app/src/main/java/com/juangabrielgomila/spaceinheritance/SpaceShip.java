package com.juangabrielgomila.spaceinheritance;

import android.util.Log;

/**
 * Created by JuanGabriel on 6/11/17.
 */

public abstract class SpaceShip {


    //Variables de la clase
    private static int numShips;
    private int shieldStrength;
    public String shipName;


    //Setters y getters
    public int getShieldStrength() {
        return shieldStrength;
    }

    private void setShieldStrength(int shieldStrength) {
        this.shieldStrength = shieldStrength;
    }



    public static int getNumShips(){
        return numShips;
    }


    //Constructor
    public SpaceShip(int shieldStrength){
        Log.i("Location", "SpaceShip constructor");
        numShips++;
        setShieldStrength(shieldStrength);
    }

    //Métodos adicionales
    public void hitDetected(){
        this.shieldStrength -= 25;
        Log.i("Incoming", "BOOOOM!!!");
        if (this.shieldStrength<=0){
            destroyShip();
        }
    }

    private void destroyShip(){
        numShips--;
        Log.i("Explosión", "La nave "+shipName+ " ha sido destruida");
    }


    public abstract void fireWeapon();


}


