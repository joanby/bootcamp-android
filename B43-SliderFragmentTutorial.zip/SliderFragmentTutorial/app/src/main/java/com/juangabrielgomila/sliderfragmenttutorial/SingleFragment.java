package com.juangabrielgomila.sliderfragmenttutorial;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * Created by JuanGabriel on 23/1/18.
 */

public class SingleFragment extends Fragment {

    public static final String MESSAGE = "d6yhn89";


    public static SingleFragment newInstance(String message){
        SingleFragment fragment = new SingleFragment();

        Bundle bundle = new Bundle(1);

        bundle.putString(MESSAGE, message);

        fragment.setArguments(bundle);

        return fragment;
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {


        String message = getArguments().getString(MESSAGE);

        View view = inflater.inflate(R.layout.fragment_layout, container, false);

        TextView textview = (TextView) view.findViewById(R.id.fragment_textview);

        textview.setText(message);

        //Aquí podéis añadir más objetos visuales al fragmento...

        return view;

    }
}
