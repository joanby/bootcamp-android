package com.juangabrielgomila.singlefragment;

import android.app.Fragment;
import android.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Conseguir el fragment manager para gestionar fragmentos
        FragmentManager manager = getFragmentManager();

        //Creamos un nuevo fragmento usando el manager
        //El identificador que utilizamos es el que hemos añadido en el container de la actividad principal
        Fragment frag = manager.findFragmentById(R.id.fragment_holder);

        //Solo inflaremos el fragmento si no se habia inicializado antes
        if (frag == null){

            //Inicializamos nuestro Single Fragment
            frag = new SingleFragment();
            manager.beginTransaction()
                    .add(R.id.fragment_holder, frag)
                    .commit();

        }


    }
}
