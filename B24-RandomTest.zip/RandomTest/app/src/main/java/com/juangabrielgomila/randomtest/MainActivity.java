package com.juangabrielgomila.randomtest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Random randomGenerator = new Random();

        //DISTRIBUCIONES UNIFORMES

        int myRandomInt = randomGenerator.nextInt(10); //myRandomInt puede valer 0,1,2,3,4,5,6,7,8,9
        //randomGenerator.nextInt()%10;

        //Para tener un número aleatorio entre 1 y 10...
        myRandomInt++;

        float myRandomFloat = randomGenerator.nextFloat();

        long myRandomLong = randomGenerator.nextLong();

        double myRandomDouble = randomGenerator.nextDouble();

        boolean myRandomBoolean = randomGenerator.nextBoolean();


        double myRandomDoubleGaussian = randomGenerator.nextGaussian();

    }
}
