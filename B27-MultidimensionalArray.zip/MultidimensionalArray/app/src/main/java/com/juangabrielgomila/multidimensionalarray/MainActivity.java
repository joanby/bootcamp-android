package com.juangabrielgomila.multidimensionalarray;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    //Random para generar números aleatorios
    Random randInt = new Random();
    //Variable para conocer el identificador de la pregunta seleccionada...
    int questionNumber = -1;


    //Estructura de array multidimensional para guardar países y capitales
    String[][] countriesAndCapitals;


    //Variable para la text view de contenido
    TextView textView;

    //Variables para saber qué posición tiene el país, y cual tiene la capital
    final int country = 0;
    final int capital = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //Inicializamos el array de países y capitales con
        //5 arrays de 2 elementos cada uno
        //Cada array tendrá país en primera posición, y capital en la segunda.
        countriesAndCapitals = new String[5][2];

        //Cargamos 5 países con sus respectivas capitales
        countriesAndCapitals[0][country] = "España";
        countriesAndCapitals[0][capital] = "Madrid";

        countriesAndCapitals[1][country] = "Francia";
        countriesAndCapitals[1][capital] = "París";

        countriesAndCapitals[2][country] = "Reino Unido";
        countriesAndCapitals[2][capital] = "Londres";

        countriesAndCapitals[3][country] = "Italia";
        countriesAndCapitals[3][capital] = "Roma";

        countriesAndCapitals[4][country] = "Brasil";
        countriesAndCapitals[4][capital] = "Brasilia";


        textView = (TextView) findViewById(R.id.text_view_question);

    }



    public void nextQuestion(View v){

        int nextQuestion = questionNumber;
        while (nextQuestion == questionNumber) {
            nextQuestion = randInt.nextInt(countriesAndCapitals.length);
        }
        questionNumber = nextQuestion;

        String countryName = countriesAndCapitals[questionNumber][country];
        String capitalName = countriesAndCapitals[questionNumber][capital];

        textView.setText("La capital de "+countryName+ " es "+capitalName);


    }
}
