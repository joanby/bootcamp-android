package com.juangabrielgomila.devicedetection;

import android.graphics.Point;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Display;
import android.view.Surface;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView txtOrientation;
    private TextView txtResolution;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtOrientation = (TextView) findViewById(R.id.txtOrientation);
        txtResolution = (TextView) findViewById(R.id.txtResolution);

    }


    public void detectDevice(View view){
        Display display = getWindowManager().getDefaultDisplay();

        txtOrientation.setText("Orientación: "+display.getRotation());

        //Surface.ROTATION_0 = 0
        //Surgace.ROTATION_90 = 1
        //Surface.ROTATION_180 = 2
        //Surgace.ROTATION_270 = 3

        Point xy = new Point();
        display.getSize(xy);
        txtResolution.setText("x = "+xy.x + " y = "+ xy.y);
    }

}
