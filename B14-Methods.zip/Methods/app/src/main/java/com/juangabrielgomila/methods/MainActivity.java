package com.juangabrielgomila.methods;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "Main Activity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        String s = joinStrings("Android", " mola ", "mucho");
        Log.i(TAG, "onCreate: "+s);

        float perimeter = getPerimeter(0.3f);
        Log.i(TAG, "onCreate: "+perimeter);

        float area = getArea(1f);
        Log.i(TAG, "onCreate: "+area);


        int x = 0;
        modify2(x);
        Log.i(TAG, "x"+x);//0


        Log.i(TAG, "\n\n=======================");

        int myAge = 29;
        String myName = "Juan Gabriel";

        printStuff(myAge);
        printStuff(myName);
        printStuff(myAge, myName);
    }



    void printStuff(int i){
        Log.i(TAG, "Este método imprime números enteros");
        Log.i(TAG, "my int = "+i);
    }


    void printStuff(String s){
        Log.i(TAG, "Este método imprime strings");
        Log.i(TAG, "my string = " + s);
    }


    void printStuff(int i, String s){
        Log.i(TAG, "Este método imprime enteros y strings combinados");
        Log.i(TAG, "my int = "+i);
        Log.i(TAG, "my string = "+s);
    }



    public String joinStrings(String s1, String s2, String s3){
        return s1+s2+s3;
    }

    public float getPerimeter(float radius){
        return 2.0f * 3.1415f*radius;
    }

    public float getArea(float radius){
        return 3.1415f * radius * radius;
    }

    public void modify2(int a){
        a += 2;
    }
    


    float getBalance(){
        String customerName = "JB";
        float balance = 45.34f;
        return balance;
    }

}
