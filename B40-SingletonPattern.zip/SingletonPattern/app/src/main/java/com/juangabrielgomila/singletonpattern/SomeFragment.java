package com.juangabrielgomila.singletonpattern;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;

/**
 * Created by JuanGabriel on 16/1/18.
 */

public class SomeFragment extends Fragment {

    private ActivityComs mActivityComs;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        mActivityComs = (ActivityComs) activity;

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        mActivityComs = (ActivityComs) context;
    }


    @Override
    public void onDetach() {
        super.onDetach();

        mActivityComs = null;

    }


    public void someBullyFunction(){

        Movie m = new Movie();
        m.setTitle("Lo que el viento se llevó");
        m.setOnRental(true);

        mActivityComs.onListItemSelected(m);



    }


}
