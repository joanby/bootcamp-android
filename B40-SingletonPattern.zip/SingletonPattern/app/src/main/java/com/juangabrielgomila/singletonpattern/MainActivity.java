package com.juangabrielgomila.singletonpattern;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements ActivityComs {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        RentalStore rs = RentalStore.getInstance();
        ArrayList<Movie> myMovies = rs.getMovies();



        RentalStore someRentalStore = RentalStore.getInstance();
        ArrayList<Movie> someMovies = someRentalStore.getMovies();

    }

    @Override
    public void onListItemSelected(Movie theMovie) {
        Toast.makeText(this, theMovie.getTitle(), Toast.LENGTH_SHORT).show();
    }
}
