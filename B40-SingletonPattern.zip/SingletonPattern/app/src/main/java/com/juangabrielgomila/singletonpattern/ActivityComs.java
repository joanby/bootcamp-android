package com.juangabrielgomila.singletonpattern;

/**
 * Created by JuanGabriel on 16/1/18.
 */

public interface ActivityComs {

    //Todos los smétodo de una interfaz siempre es abstractos
    void onListItemSelected(Movie theMovie);

}
