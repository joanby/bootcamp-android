package com.juangabrielgomila.singletonpattern;

import java.util.ArrayList;

/**
 * Created by JuanGabriel on 16/1/18.
 */

public class RentalStore {

    //Voy a instanciar un objeto de mi mismo
    //Va a ser el único objeto instanciado de la clase Rental Store
    private static RentalStore sharedInstance = new RentalStore();

    //Gestor de mis películas
    private ArrayList<Movie> mMovies;


    //Cualquiera que quiera usar mi síngleton, necesitará
    //llamar al método getInstance()
    public static RentalStore getInstance(){
        return sharedInstance;
    }

    //Para que nadie pueda crear ninguna otra Rental Store
    //hago que su único constructor sea privado
    private RentalStore(){
        //El constructor inicializa el array de películas vacío
        mMovies = new ArrayList<Movie>();
    }

    public ArrayList<Movie> getMovies(){
        return mMovies;
    }

    public Movie getMovieAt(int index){
        return mMovies.get(index);
    }


    public void addMovie(Movie m){
        mMovies.add(m);
    }

    public void removeMovie(Movie m) {
        mMovies.remove(m);
    }

}
