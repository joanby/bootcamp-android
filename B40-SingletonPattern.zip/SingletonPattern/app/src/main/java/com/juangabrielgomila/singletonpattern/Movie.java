package com.juangabrielgomila.singletonpattern;

/**
 * Created by JuanGabriel on 16/1/18.
 */

public class Movie {

    private String mTitle;
    private boolean mOnRental;

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String title) {
        this.mTitle = mTitle;
    }

    public boolean isOnRental() {
        return mOnRental;
    }

    public void setOnRental(boolean onRental) {
        this.mOnRental = mOnRental;
    }
}
