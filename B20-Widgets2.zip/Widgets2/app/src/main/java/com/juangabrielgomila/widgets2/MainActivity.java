package com.juangabrielgomila.widgets2;

import android.provider.MediaStore;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



        //ACTIVITY_RADIO_BUTTONS
        setContentView(R.layout.activity_radio_button);

        final RadioGroup radioGroup = (RadioGroup) findViewById(R.id.radio_group);
        //RadioButton rb1 = (RadioButton) findViewById(R.id.rb1);
        //RadioButton rb2 = (RadioButton) findViewById(R.id.rb2);
        //RadioButton rb3 = (RadioButton) findViewById(R.id.rb3);

        radioGroup.setOnCheckedChangeListener(
                new RadioGroup.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup radioGroup, @IdRes int checkedID) {
                        //Código cuando se cambia alguno de los radio buttons de estado...
                        Log.d("RADIO BUTTON", "onCheckedChanged: "+checkedID);

                        RadioButton rb = (RadioButton) radioGroup.findViewById(checkedID);

                        Log.d("RADIO BUTTON", "onCheckedChanged: "+ rb.getId());

                        switch (rb.getId()){
                            case R.id.rb1:
                                Log.d("RADIO BUTTON", "Eres un maromo ");
                                break;

                            case R.id.rb2:
                                Log.d("RADIO BUTTON", "Eres una señorita ");
                                break;

                            case R.id.rb3:
                                Log.d("RADIO BUTTON", "¿Eres un orco o qué? ");
                                break;
                        }



                    }
                }
        );



        //SWITCH BUTTON
        Switch mySwitch = (Switch) findViewById(R.id.switch1);
        mySwitch.setOnCheckedChangeListener(
                new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {

                        if (isChecked){
                            compoundButton.setText("Ahora estoy activo =D ");
                            radioGroup.setVisibility(View.VISIBLE);
                        }else{
                            compoundButton.setText("Ahora no estoy activo =(");
                            radioGroup.setVisibility(View.INVISIBLE);
                        }




                    }
                }
        );


        CheckBox myCheckbox = (CheckBox) findViewById(R.id.checkBox);
        myCheckbox.setOnCheckedChangeListener(
                new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                        if (isChecked){
                            compoundButton.setText(getString(R.string.terms_true));
                        } else {
                            compoundButton.setText(getString(R.string.terms_false));
                        }
                    }
                }
        );

        myCheckbox.setText(getString(R.string.terms_false));


        WebView myWebView = (WebView) findViewById(R.id.web_view);
        myWebView.loadUrl("http://google.com");


       //ACTVITY_MAIN
       /* setContentView(R.layout.activity_main);


        EditText myEditText = (EditText) findViewById(R.id.editText);

        String editTextContent = myEditText.getText().toString();
        //Ahora, la variable editTextContent contiene lo que sea que haya introducido el usuario en la caja de texto.


        ImageView myImageView = (ImageView) findViewById(R.id.imageView);
        myImageView.setAlpha(0.5f);

        */



        //TEXTVIEW FROM LAYOUT
        /*TextView myTextView = (TextView) findViewById(R.id.tv_hello);

        myTextView.setText("Buenos días, hoy es Lunes!");

        myTextView.setVisibility(View.GONE);

        myTextView.setText("BOOO!!!!!");

        myTextView.setVisibility(View.VISIBLE);


        //BUTTON FROM CODE
        Button myButton = new Button(this);

        myButton.setText("Hola que ase!");

        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.linear_layout);

        linearLayout.addView(myButton);*/



        //LAYOUT AND BUTTON FROM CODE
       /*LinearLayout linearLayout = new LinearLayout(this);
        Button myButton = new Button(this);
        myButton.setText("Un botón por código!! =D");
        linearLayout.addView(myButton);
        setContentView(linearLayout);*/


    }
}
