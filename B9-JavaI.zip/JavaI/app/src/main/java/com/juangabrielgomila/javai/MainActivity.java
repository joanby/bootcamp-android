package com.juangabrielgomila.javai;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;


/**
 * @author Juan Gabriel
 */
public class MainActivity extends AppCompatActivity {


    int unreadMessages; //int guarda nùmeros de 32 bits ~2 billones
    long primeNumber;   //long  guarda números de 64 bits, 9,2 x 10 ^18
    float pi; //float guarda números decimales de hasta 8 cifras decimales
    double precisePi; //double guarda el doble de precisión (en bytes) que un float...
    boolean isMyFriend; //boolean toma valores binarios true o false
    char aSingleCharacter; //char guarda uno y solo un caracter ASCII


    String contactName ;
    //Comentario de una línea

    //Comentario
    //de dos líneas

    /**
    * Comentario multilinea
    * que mola más y sirve
    * para contar una historia
    * @param savedInstanceState: sirve para guardar el estado entre sesiones
    * */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        Log.i("Main Activity", "onCreate: "+contactName + " mensajes sin leer");

        unreadMessages = 6;

        int newUnreadMessages = 11;
        unreadMessages = newUnreadMessages; //unreadMessages = 11;

        newUnreadMessages = 25; //newUnreadMessages = 25;

        newUnreadMessages = unreadMessages/5 + 2*newUnreadMessages + 5 -6;

        newUnreadMessages++;

        ++newUnreadMessages;

        newUnreadMessages--;

        --newUnreadMessages;

        newUnreadMessages += 5;

        newUnreadMessages =+ 5;

        sumaUno(4);
    }


    /**
     * Método que suma uno al valor actual
     * @param i entero que quiero sumar
     * @return entero que resulta de sumar 1 al parámetro original
     *
     * */
    public int sumaUno(int i){
        return i+1;
    }
}
