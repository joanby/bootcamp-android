package com.juangabrielgomila.contacts;

/**
 * Created by JuanGabriel on 16/1/18.
 */

public interface ActivityComs {

    void onListItemSelected(int position);

}
