package com.juangabrielgomila.contacts;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * Created by JuanGabriel on 16/1/18.
 */

public class AddressBook {

    private static AddressBook sharedInstance = new AddressBook();

    private ArrayList<Contact> mContacts;


    //Some hardcoded dummy data

    Contact c1 = new Contact("Bill",
            "Clinton",
            "La Casa Blanca",
            "Washington",
            "DC1");

    Contact c2 = new Contact("Jon",
            "Snow",
            "El Muro",
            "Más allá de Invernalia",
            "Muro001");

    Contact c3 = new Contact("Christian",
            "Grey",
            "Torre Grey",
            "Seattle",
            "Set69");


    public static AddressBook getInstance(){
        return sharedInstance;
    }

    private AddressBook(){
        mContacts = new ArrayList<Contact>();

        mContacts.add(c1);
        mContacts.add(c2);
        mContacts.add(c3);
    }

    public ArrayList<Contact> getContacts(){
        return mContacts;
    }


}
