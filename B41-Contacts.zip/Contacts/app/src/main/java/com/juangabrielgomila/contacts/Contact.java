package com.juangabrielgomila.contacts;

import java.io.Serializable;

/**
 * Created by JuanGabriel on 16/1/18.
 */

public class Contact implements Serializable {

    private String mName;
    private String mSurname;
    private String mAddress1;
    private String mAddress2;
    private String mZipCode;


    public Contact(String name,
                   String surname,
                   String address1,
                   String address2,
                   String zipCode){

        this.mName = name;
        this.mSurname = surname;
        this.mAddress1 = address1;
        this.mAddress2 = address2;
        this.mZipCode = zipCode;
    }


    public String getName() {
        return mName;
    }

    public String getSurname() {
        return mSurname;
    }

    public String getAddress1() {
        return mAddress1;
    }

    public String getAddress2() {
        return mAddress2;
    }

    public String getZipCode() {
        return mZipCode;
    }
}
