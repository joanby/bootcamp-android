package com.juangabrielgomila.contacts;

import android.app.ListFragment;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by JuanGabriel on 16/1/18.
 */

public class AddressListFragment extends ListFragment {

    private ActivityComs mActivityComs;

    private ArrayList<Contact> contacts;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        contacts = AddressBook.getInstance().getContacts();
        AddressListAdapter adapter = new AddressListAdapter(contacts);
        setListAdapter(adapter);

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        //Context es de tipo Main Activity, pero haremos un casting a la interfaz Activity Coms
        mActivityComs = (ActivityComs) context;
    }


    @Override
    public void onDetach() {
        super.onDetach();
        //Ya no necesito la interfaz, pues la destruyo
        mActivityComs = null;
    }


    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {

        mActivityComs.onListItemSelected(position);

    }







    public class AddressListAdapter extends ArrayAdapter<Contact> {


        public AddressListAdapter(ArrayList<Contact> contacts){
            super(getActivity(),R.layout.list_item, contacts);
        }


        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            //Si la celda de la tabla me llega nula es que nadie la ha inicializado antes...
            if(convertView == null) {
                LayoutInflater inflater = (LayoutInflater) getActivity().getLayoutInflater();
                convertView = inflater.inflate(R.layout.list_item, null);
            }

            Contact currentContact = getItem(position);

            TextView txtName = (TextView) convertView.findViewById(R.id.txt_name);

            txtName.setText(currentContact.getName() + " " +currentContact.getSurname());

            return convertView;
        }
    }



}
