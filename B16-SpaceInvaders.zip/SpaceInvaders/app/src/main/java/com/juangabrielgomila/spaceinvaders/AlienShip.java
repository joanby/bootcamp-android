package com.juangabrielgomila.spaceinvaders;

import android.util.Log;

/**
 * Created by JuanGabriel on 30/10/17.
 */

public class AlienShip {

    //Variables de clase
    private static int numShips;
    private int shieldStrength;
    public String shipName;


    public int getShieldStrength() {
        return this.shieldStrength;
    }

    private void setShieldStrength(int shieldStrength) {
        if (shieldStrength<0||shieldStrength>100){
            return;
        }
        this.shieldStrength = shieldStrength;
    }

    public static int getNumShips() {
        return numShips;
    }





    //Constructor
    public AlienShip(){
        numShips++;

        this.setShieldStrength(100);
    }



    //Métodos
    public void detectHit(){

        this.shieldStrength -= 25;

        Log.i("Hit Detected", "BOOOOOM!!");

        if (this.shieldStrength<=0){
            destroyShip();
        }

    }

    private void destroyShip(){
        numShips--;
        Log.i("Explosion final", this.shipName + " ha sido destruida. ");
    }




}
