package com.juangabrielgomila.spaceinvaders;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        AlienShip girlShip = new AlienShip();
        AlienShip boyShip = new AlienShip();


        Log.i("Numero de naves", "Hay  "+AlienShip.getNumShips()+" naves en pantalla. ");

        girlShip.shipName = "Samsa Stark";
        boyShip.shipName = "Indiana Jones";

        //Esto no puede funcionar porque la variable es privada
        //girlShip.shieldStrength = 50000;

        Log.i("Vida", "La vida de "+girlShip.shipName + "es de "+girlShip.getShieldStrength());
        Log.i("Vida", "La vida de "+boyShip.shipName + "es de "+boyShip.getShieldStrength());

        //evito que algún hacker me ponga vida infinita constantemente
        /*while (true){
            girlShip.setShieldStrength(100);
        }*/


        girlShip.detectHit();
        Log.i("Vida", "La vida de "+girlShip.shipName + "es de "+girlShip.getShieldStrength());
        Log.i("Vida", "La vida de "+boyShip.shipName + "es de "+boyShip.getShieldStrength());


        boyShip.detectHit();
        boyShip.detectHit();
        boyShip.detectHit();
        Log.i("Vida", "La vida de "+girlShip.shipName + "es de "+girlShip.getShieldStrength());
        Log.i("Vida", "La vida de "+boyShip.shipName + "es de "+boyShip.getShieldStrength());



        boyShip.detectHit();//Es el 4º impacto, y por tanto debería morir...
        Log.i("Vida", "La vida de "+girlShip.shipName + "es de "+girlShip.getShieldStrength());
        Log.i("Vida", "La vida de "+boyShip.shipName + "es de "+boyShip.getShieldStrength());


        Log.i("Numero de naves", "Hay  "+AlienShip.getNumShips()+" naves en pantalla. ");



    }
}
