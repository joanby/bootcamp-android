package com.juangabrielgomila.layouts;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by JuanGabriel on 9/10/17.
 */

public class MyCoolActivity extends AppCompatActivity {
}
