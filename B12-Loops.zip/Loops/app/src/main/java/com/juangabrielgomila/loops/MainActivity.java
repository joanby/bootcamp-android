package com.juangabrielgomila.loops;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        int x = 10;

        while (x >0){
            x--;
            //hacer cosas dentro del bucle
        }

        int newMessages = 4;
        int unreadMessages = 0;

        while (newMessages>0 || unreadMessages>0){
            //mostrar el sigueinte mensaje
        }

        int y = 1;
        while (y>0){
            y--; // y = 0;
            //y aquí ya vale cero
            //pero como ya he entrado en el bucle
            //seguiré ejecutando lo que haya
            //aquí
            //y aquí
            //y aquí...
        }


        int z = 0;
        while (true){
            z++;
            //z se hará muy muy grande
            //pero nunca saldremos del bucle
            //así que seguiremos ejecutando
            //hasta quedarnos sin memoria
            if(z > 1000000) {
                break;
            }
            //Este bucle se pararía de ejecutar cuando z = 1.000.000
        }

        Log.i("Z", "La z vale: "+z);


        int tooBig = 10;
        int tooBigToPrint = 5;
        z=0;

        while (true){
            z++;
            if (z == tooBig){
                break;
            }

            if (z>=tooBigToPrint){
                continue;
            }
            Log.i("Value of Z", "z"+z);
        }




        int x1 = 0;
        do{
            x1++;
        }while (x1<10);



       // for (/*declaración e inicialización*/; /*condición de iteración*/; /*cambio después de cada iteración del bucle*/){
            //cuerpo del bucle
        //}

        for (int i = 0; i < 10; i++){
            Log.i("Value of i", "onCreate: "+i);
        }



        int[] primeNumbers = {2,3,5,7,11,13,17,19,23,29};

        for (int i = 0; i < primeNumbers.length; i++){
            Log.i("PN", "onCreate: "+primeNumbers[i]);
        }

        for (int primeNumber : primeNumbers){
            Log.i("PN", "onCreate: "+primeNumber);
        }


    }
}
