package com.juangabrielgomila.wartime;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //Si viene un enemigo, dispárale!
        boolean enemyIsComingOverTheBridge = true;
        int numberOfEnemyTroops = 5;
        int numberOfFriendlyTroops = 8;

        boolean isWavingWhiteFlag = true;

        if(!isWavingWhiteFlag) {
            if (enemyIsComingOverTheBridge && (numberOfFriendlyTroops >= numberOfEnemyTroops)) {
                //Dispara al enemigo
            } else if (enemyIsComingOverTheBridge && (numberOfFriendlyTroops < numberOfEnemyTroops)) {
                //Volar el puente, que no pasen!
            } else {
                //Mantened posición en el puente
            }
        } else {
            //Tomar a los rendidos de prisioneros
        }



        String lastOrder = "dame agua";
        String TAG = "ORDER";

        switch (lastOrder){

            case "go north":
                Log.i(TAG, "Ves al norte");
                break;

            case "go south":
                Log.i(TAG, "Ves al sur");
                break;

            case "go west":
                goWest();
                Log.i(TAG, "Ves al oeste");
                break;

            case "go east":
                Log.i(TAG, "Ves al este");
                break;

            case "take sword":
                Log.i(TAG, "Coge la espada");
                break;

            //Todos los casos extra que quisieramos

            default:
                Log.i(TAG, "Lo siento, no hablo la lengua de los orcos");
                break;
        }



        /*
        int speed = 150;

        switch (speed){

            case 0:
            case 1:
            case 5:
                //estás parado
                break;
            case 1...60:
                //vas mas lento que el caballo del malo
                break;

            case 61...120:
                //vas a buena velocidad
                break;

            case 120...:
                //te va a caer una multa melón!
                break;

            default:
                //voy marcha atrás
                break;

        }*/

    }


    public void goWest(){

    }
}
